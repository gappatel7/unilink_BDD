package com.unilink.bdd;

import com.unilink.bdd.loadProperty.LoadProperty;
import com.unilink.bdd.pages.ContactUsPage;
import com.unilink.bdd.pages.HomePage;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;

import java.awt.*;

/**
 * Created by  :  Gaurang Patel
 * since : Sunday  26/04/2020
 * TIME  : 12:51
 **/

public class MyStepdefs {

    @Steps
    HomePage homePage;
    @Steps
    ContactUsPage contactUsPage;


    @Step("I am on the UniLink HomePage")
    @Given("^I am on UniLink homepage$")
    public void iAmOnUniLinkHomepage() {

        homePage.clickOnContactUsLink();
    }

    @Step("I click on contact us link")
    @When("^I click on contact us link$")
    public void iClickOnContactUsLink()
    {

        homePage.clickOnContactUsLink();
    }

    @Step("I enter name my name")
    @And("^I enter name my name \"([^\"]*)\"$")
    public void iEnterNameMyName(String name) {
        contactUsPage.enterYourName(name);
    }

    @Step("I enter email my email")
    @And("^I enter email my email \"([^\"]*)\"$")
    public void iEnterEmailMyEmail(String email) {
        contactUsPage.enterYourEmailField(email);
    }

    @Step("I click on sign up button")
    @And("^I click on sign up button$")
    public void iClickOnSignUpButton() {
        contactUsPage.clickOnSignUp();
    }

    @Step("Thank you massage should be displayed")
    @Then("^Thank you massage should be displayed$")
    public void thankYouMassageShouldBeDisplayed() {
        Assert.assertEquals("Thank you, your sign-up request was successful! Please check your e-mail inbox.", contactUsPage.getThankYouMassage());
    }
}

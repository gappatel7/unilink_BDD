package com.unilink.bdd;

import com.unilink.bdd.basePage.BasePage;
import com.unilink.bdd.browserSelector.BrowserSelector;
import com.unilink.bdd.loadProperty.LoadProperty;
import cucumber.api.java.After;
import cucumber.api.java.Before;

/**
 * Created by  :  Gaurang Patel
 * since : Saturday  25/04/2020
 * TIME  : 23:45
 **/
public class Hooks extends BasePage {
    BrowserSelector browserSelector = new BrowserSelector();
    LoadProperty loadProperty = new LoadProperty();

    @Before
    public void setUp(){
        browserSelector.selectBrowser(loadProperty.getProperty("browser"));
    }
    @After
    public void tearDown(){
        driver.quit();
    }
}

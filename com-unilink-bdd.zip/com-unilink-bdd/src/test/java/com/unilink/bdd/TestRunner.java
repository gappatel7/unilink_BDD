package com.unilink.bdd;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

/**
 * Created by  :  Gaurang Patel
 * since : Saturday  25/04/2020
 * TIME  : 23:46
 **/
@RunWith(CucumberWithSerenity.class)
@CucumberOptions(

        features = ".",
        plugin = {"pretty","html:target/cucumber-report"},
        dryRun = false,
        tags = "@Sanity",
        monochrome = true
)

public class TestRunner {
}

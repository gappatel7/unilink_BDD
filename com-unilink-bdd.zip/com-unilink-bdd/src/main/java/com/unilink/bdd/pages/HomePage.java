package com.unilink.bdd.pages;

import com.unilink.bdd.utility.Util;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.events.WebDriverEventListener;

/**
 * Created by  :  Gaurang Patel
 * since : Saturday  25/04/2020
 * TIME  : 21:20
 **/
public class HomePage extends Util {

    @FindBy (xpath = "//a[contains(text(),'Contact Us')]")
    WebElement _contactUs;

    public void clickOnContactUsLink(){
    clickOnElement(_contactUs);
    }
}

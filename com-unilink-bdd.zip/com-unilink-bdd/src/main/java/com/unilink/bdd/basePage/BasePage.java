package com.unilink.bdd.basePage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by  :  Gaurang Patel
 * since : Saturday  25/04/2020
 * TIME  : 21:16
 **/
public class BasePage {

    public static WebDriver driver;

    public BasePage(){

        PageFactory.initElements(driver,this);
    }
}

package com.unilink.bdd.pages;

import com.unilink.bdd.utility.Util;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by  :  Gaurang Patel
 * since : Saturday  25/04/2020
 * TIME  : 22:52
 **/
public class ContactUsPage extends Util {

    @FindBy(name = "LNAME")
    WebElement _nameField;

    @FindBy(id = "mc4wp_email")
    WebElement _emailField;

    @FindBy(xpath = "//div[@class='mc4wp-form-fields']//input[3]")
    WebElement _signUp;

    @FindBy (xpath = "//p[contains(text(),'Thank you, your sign-up request was successful! Pl')]")
    WebElement _thankYouMassage;

    public void enterYourName(String name){
        sendTextToElement(_nameField,name);
    }
    public void enterYourEmailField(String email){
        sendTextToElement(_emailField,email);
    }
    public void clickOnSignUp(){
        clickOnElement(_signUp);
    }
    public String getThankYouMassage(){
        return getTextFromElement(_thankYouMassage);
    }
}

